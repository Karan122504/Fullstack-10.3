# Social Media App (Minimal runnable)

This archive contains a minimal **React (Create React App) frontend** and **Express + Sequelize backend** using **PostgreSQL**.

Features:
- Register / Login (JWT)
- Create posts with optional image upload (saved locally under `/backend/uploads`)
- Feed showing posts
- Docker + docker-compose for local run
- Dockerfiles for frontend and backend (ready for AWS container deployment)

## Quick local run (recommended)
Requires Docker & Docker Compose.

1. Extract the ZIP.
2. From the project root run:
   ```
   docker-compose up --build
   ```
3. Open:
   - Frontend: http://localhost:3000
   - Backend API: http://localhost:4000
4. Create an account and start posting.

## Run without Docker (you must have PostgreSQL)
1. Create a Postgres database and set `DATABASE_URL` environment variable (see `backend/.env.example`).
2. Start backend:
   ```
   cd backend
   npm install
   cp .env.example .env
   # edit .env if needed
   npm start
   ```
3. Start frontend:
   ```
   cd frontend
   npm install
   cp .env.example .env
   npm start
   ```

## Notes
- For AWS deployment: use the provided Dockerfiles or build images and deploy to ECS/Fargate or Elastic Beanstalk.
- This is a minimal starter to help you build your capstone. Extend as needed (likes, comments, validation, security hardening).

