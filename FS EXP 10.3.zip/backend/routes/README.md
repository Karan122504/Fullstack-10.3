No extra route files; all endpoints are in server.js for simplicity.
