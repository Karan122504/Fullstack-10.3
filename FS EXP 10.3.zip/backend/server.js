require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const { Sequelize, DataTypes } = require('sequelize');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const multer = require('multer');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');

const app = express();
app.use(cors());
app.use(express.json());

const PORT = process.env.PORT || 4000;
const DATABASE_URL = process.env.DATABASE_URL;
if (!DATABASE_URL) {
  console.warn('DATABASE_URL not set. Set it in .env or use docker-compose (recommended).');
}

const sequelize = new Sequelize(DATABASE_URL, {
  logging: false,
});

// Models
const User = sequelize.define('User', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  username: { type: DataTypes.STRING, unique: true, allowNull: false },
  email: { type: DataTypes.STRING, unique: true, allowNull: false },
  password_hash: { type: DataTypes.STRING, allowNull: false },
  avatar_url: { type: DataTypes.STRING },
}, { tableName: 'users', timestamps: true });

const Post = sequelize.define('Post', {
  id: { type: DataTypes.UUID, defaultValue: DataTypes.UUIDV4, primaryKey: true },
  user_id: { type: DataTypes.UUID, allowNull: false },
  content: { type: DataTypes.TEXT, allowNull: false },
  image_url: { type: DataTypes.STRING },
}, { tableName: 'posts', timestamps: true });

User.hasMany(Post, { foreignKey: 'user_id' });
Post.belongsTo(User, { foreignKey: 'user_id' });

// Simple auth middleware
function authMiddleware(req, res, next) {
  const header = req.headers.authorization;
  if (!header) return res.status(401).json({ message: 'No token' });
  const token = header.split(' ')[1];
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET || 'change_this_secret');
    req.userId = payload.id;
    next();
  } catch (e) {
    return res.status(401).json({ message: 'Invalid token' });
  }
}

// Multer for local uploads
const uploadsDir = process.env.UPLOADS_DIR || 'uploads';
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });
const storage = multer.diskStorage({
  destination: function (req, file, cb) { cb(null, uploadsDir); },
  filename: function (req, file, cb) { const name = Date.now() + '_' + file.originalname; cb(null, name); }
});
const upload = multer({ storage });

// Routes
app.get('/health', (req, res) => res.json({ ok: true }));

app.post('/api/auth/register', async (req, res) => {
  const { username, email, password } = req.body;
  if (!email || !password || !username) return res.status(400).json({ message: 'Missing fields' });
  const existing = await User.findOne({ where: { email }});
  if (existing) return res.status(400).json({ message: 'Email in use' });
  const hash = await bcrypt.hash(password, 10);
  const user = await User.create({ username, email, password_hash: hash });
  const token = jwt.sign({ id: user.id }, process.env.JWT_SECRET || 'change_this_secret', { expiresIn: '7d' });
  res.json({ token, user: { id: user.id, username: user.username, email: user.email }});
});

app.post('/api/auth/login', async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ message: 'Missing fields' });
  const user = await User.findOne({ where: { email }});
  if (!user) return res.status(401).json({ message: 'Invalid credentials' });
  const ok = await bcrypt.compare(password, user.password_hash);
  if (!ok) return res.status(401).json({ message: 'Invalid credentials' });
  const token = jwt.sign({ id: user.id }, process.env.JWT_SECRET || 'change_this_secret', { expiresIn: '7d' });
  res.json({ token, user: { id: user.id, username: user.username, email: user.email }});
});

app.post('/api/uploads', authMiddleware, upload.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ message: 'No file' });
  const publicUrl = `${req.protocol}://${req.get('host')}/${uploadsDir}/${req.file.filename}`;
  res.json({ url: publicUrl, filename: req.file.filename });
});

app.use(`/${uploadsDir}`, express.static(path.join(__dirname, uploadsDir)));

app.post('/api/posts', authMiddleware, async (req, res) => {
  const { content, image_url } = req.body;
  if (!content) return res.status(400).json({ message: 'Content required' });
  const post = await Post.create({ user_id: req.userId, content, image_url });
  res.json(post);
});

app.get('/api/posts/feed', authMiddleware, async (req, res) => {
  const posts = await Post.findAll({
    include: [{ model: User, attributes: ['id','username'] }],
    order: [['createdAt','DESC']],
    limit: 100
  });
  res.json(posts);
});

// Sync DB then start
(async () => {
  try {
    await sequelize.authenticate();
    await sequelize.sync();
    app.listen(PORT, () => console.log('Server running on', PORT));
  } catch (err) {
    console.error('Unable to start server:', err);
    process.exit(1);
  }
})();
