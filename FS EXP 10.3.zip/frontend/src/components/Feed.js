import React, { useEffect, useState } from 'react';

export default function Feed({ api }) {
  const [posts, setPosts] = useState([]);

  const load = async () => {
    try {
      const r = await api.get('/posts/feed');
      setPosts(r.data);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => { load(); }, []);

  return (
    <div style={{marginTop:10}}>
      <h3>Feed</h3>
      {posts.map(p => (
        <div key={p.id} className="post">
          <div><strong>{p.User?.username || 'unknown'}</strong> <small>{new Date(p.createdAt).toLocaleString()}</small></div>
          <div>{p.content}</div>
          {p.image_url && <div><img src={p.image_url} style={{maxWidth:'100%'}} alt="post"/></div>}
        </div>
      ))}
    </div>
  );
}
