import React, { useState } from 'react';

export default function CreatePost({ api, onPosted }) {
  const [content, setContent] = useState('');
  const [file, setFile] = useState(null);

  const submit = async (e) => {
    e.preventDefault();
    try {
      let image_url = null;
      if (file) {
        const form = new FormData();
        form.append('file', file);
        const r = await api.post('/uploads', form, { headers: {'Content-Type': 'multipart/form-data'}});
        image_url = r.data.url;
      }
      await api.post('/posts', { content, image_url });
      setContent(''); setFile(null);
      onPosted && onPosted();
    } catch (err) {
      alert(err.response?.data?.message || err.message);
    }
  };

  return (
    <form onSubmit={submit} style={{border:'1px solid #eee', padding:10, marginTop:10}}>
      <textarea placeholder="What's on your mind?" value={content} onChange={e=>setContent(e.target.value)} style={{width:'100%'}}/>
      <div style={{marginTop:6}}>
        <input type="file" onChange={e=>setFile(e.target.files[0])}/>
      </div>
      <button style={{marginTop:6}}>Post</button>
    </form>
  );
}
