import React, { useState, useEffect } from 'react';
import axios from 'axios';
import CreatePost from './components/CreatePost';
import Feed from './components/Feed';

const API = process.env.REACT_APP_API_URL || 'http://localhost:4000/api';

function App() {
  const [token, setToken] = useState(localStorage.getItem('token')||'');
  const [user, setUser] = useState(localStorage.getItem('user')?JSON.parse(localStorage.getItem('user')):null);

  useEffect(()=> {
    if (token) localStorage.setItem('token', token); else localStorage.removeItem('token');
    if (user) localStorage.setItem('user', JSON.stringify(user)); else localStorage.removeItem('user');
  }, [token, user]);

  const api = axios.create({ baseURL: API });
  api.interceptors.request.use(cfg => {
    if (token) cfg.headers.Authorization = `Bearer ${token}`;
    return cfg;
  });

  const logout = () => { setToken(''); setUser(null); };

  return (
    <div className="app">
      <h1>Social App (Local)</h1>
      {!token ? <AuthPanel setToken={setToken} setUser={setUser} api={api} /> :
        <>
          <div style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
            <div>Welcome, {user?.username}</div>
            <button onClick={logout}>Logout</button>
          </div>
          <CreatePost api={api} onPosted={()=>{}} />
          <Feed api={api} />
        </>
      }
      <hr/>
      <small>API: {API}</small>
    </div>
  );
}

function AuthPanel({ setToken, setUser, api }) {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('user@example.com');
  const [password, setPassword] = useState('password');
  const [username, setUsername] = useState('user1');

  const submit = async (e) => {
    e.preventDefault();
    try {
      const url = isLogin ? '/auth/login' : '/auth/register';
      const payload = isLogin ? { email, password } : { email, password, username };
      const r = await api.post(url, payload);
      setToken(r.data.token);
      setUser(r.data.user);
    } catch (err) {
      alert(err.response?.data?.message || err.message);
    }
  };

  return (
    <div style={{border:'1px solid #ccc', padding:10}}>
      <h3>{isLogin? 'Login' : 'Register'}</h3>
      <form onSubmit={submit}>
        {!isLogin && <div><input value={username} onChange={e=>setUsername(e.target.value)} placeholder="username"/></div>}
        <div><input value={email} onChange={e=>setEmail(e.target.value)} placeholder="email"/></div>
        <div><input value={password} onChange={e=>setPassword(e.target.value)} placeholder="password" type="password"/></div>
        <button type="submit">{isLogin? 'Login' : 'Register'}</button>
      </form>
      <button onClick={()=>setIsLogin(!isLogin)} style={{marginTop:8}}>{isLogin? 'Switch to Register' : 'Switch to Login'}</button>
    </div>
  );
}

export default App;
